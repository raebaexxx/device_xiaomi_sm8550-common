cmd_usr/include/asm/msgbuf.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/msgbuf.h usr/include/asm/msgbuf.h
