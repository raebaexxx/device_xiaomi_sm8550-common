cmd_usr/include/asm/termbits.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/termbits.h usr/include/asm/termbits.h
