cmd_usr/include/asm/ioctls.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/ioctls.h usr/include/asm/ioctls.h
