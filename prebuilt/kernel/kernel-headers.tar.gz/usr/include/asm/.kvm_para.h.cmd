cmd_usr/include/asm/kvm_para.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/kvm_para.h usr/include/asm/kvm_para.h
