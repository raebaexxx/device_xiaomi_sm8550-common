cmd_usr/include/asm/types.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/types.h usr/include/asm/types.h
