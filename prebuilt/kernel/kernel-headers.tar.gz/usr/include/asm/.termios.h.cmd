cmd_usr/include/asm/termios.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/termios.h usr/include/asm/termios.h
