cmd_usr/include/asm/ipcbuf.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/ipcbuf.h usr/include/asm/ipcbuf.h
