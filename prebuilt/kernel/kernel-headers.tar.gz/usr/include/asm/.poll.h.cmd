cmd_usr/include/asm/poll.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/poll.h usr/include/asm/poll.h
