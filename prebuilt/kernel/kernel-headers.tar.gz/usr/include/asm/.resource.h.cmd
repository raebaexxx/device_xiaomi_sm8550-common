cmd_usr/include/asm/resource.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/resource.h usr/include/asm/resource.h
