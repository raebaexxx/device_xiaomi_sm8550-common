cmd_usr/include/asm/shmbuf.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/shmbuf.h usr/include/asm/shmbuf.h
