cmd_usr/include/asm/sembuf.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/sembuf.h usr/include/asm/sembuf.h
