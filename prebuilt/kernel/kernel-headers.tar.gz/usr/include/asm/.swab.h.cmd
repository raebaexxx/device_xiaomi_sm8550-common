cmd_usr/include/asm/swab.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/swab.h usr/include/asm/swab.h
