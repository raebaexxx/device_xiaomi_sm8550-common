cmd_usr/include/asm/ioctl.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/ioctl.h usr/include/asm/ioctl.h
