cmd_usr/include/asm/errno.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/errno.h usr/include/asm/errno.h
