cmd_usr/include/linux/version.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh include/generated/uapi/linux/version.h usr/include/linux/version.h
