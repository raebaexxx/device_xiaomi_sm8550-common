cmd_usr/include/asm/siginfo.h := sh /home/raebae/roms/pixelos/kernel/xiaomi/sm8550/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/siginfo.h usr/include/asm/siginfo.h
